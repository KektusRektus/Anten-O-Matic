/*
 * Miscellaneous support functions for nec2++
 */

#include "misc.h"

#include <iostream>
#include <cctype>

using namespace std;

/*------------------------------------------------------------------------*/

/*  usage()
 *
 *  prints usage information
 */

void usage(void)
{
  cerr << "usage: nec2++ [-i<input-file-name>] [-o<output-file-name>]"
      "\n       -g: print maximum gain to stdout."
      "\n       -b: Perform NEC++ Benchmark."
      "\n       -s: print result summary to standard output."
      "\n       -c: print results in comma-separated-value (CSV) format,"
      "\n           this options is used in conjunction with (-s) above."
      "\n       -h: print this usage information and exit."
      "\n       -v: print nec2++ version number and exit.\n";

} /* end of usage() */


/*------------------------------------------------------------------------*/
/* Returns process time (user+system) BUT in _msec_ */

#if defined(__EMSCRIPTEN__)
/* WASM stub: no process-timing syscalls available */
void secnds( nec_float *x)
{
	*x = 0.0;
}
#elif !defined(_WIN32)
#include <sys/times.h>
#include <unistd.h>
void secnds( nec_float *x)
{
	struct tms buffer;
	
	times(&buffer);
	    *x = 1000.0 * ( static_cast<nec_float>(buffer.tms_utime + buffer.tms_stime) ) /
	        ( static_cast<nec_float>(sysconf(_SC_CLK_TCK)) );
}
#else
#include <time.h>
void secnds( nec_float *x)
{
	nec_float c = nec_float(clock());
	*x = (1000.0 * c) / CLOCKS_PER_SEC;
}
#endif


/*------------------------------------------------------------------*/

/*  load_line()
 *
 *  loads a line from a file, aborts on failure. lines beginning
 *  with a '#' are ignored as comments. A single-quote (') starts an
 *  inline comment (4nec2 compatibility). at the end of file EOF is
 *  returned.
 */

int load_line( char *buff, FILE *pfile )
{
	int num_chr = 0; /* number of characters read, excluding lf/cr */
	int eof = 0; /* EOF flag */
	int chr;     /* character read by getc */
	
	/* clear buffer at start */
	buff[0] = '\0';
	
	/* ignore commented lines, white spaces and eol/cr */
	if( (chr = fgetc(pfile)) == EOF )
		return( EOF );
	
	while( (chr == '#') ||
	            (chr == ' ') ||
	            (chr == CR ) ||
	            (chr == LF ) ) {
		/* go to the end of line (look for lf or cr) */
		while( (chr != CR) && (chr != LF) )
			if( (chr = fgetc(pfile)) == EOF )
				return( EOF );
	
		/* dump any cr/lf remaining */
		while( (chr == CR) || (chr == LF) )
			if( (chr = fgetc(pfile)) == EOF )
				return( EOF );
	} /* end of while( (chr == '#') || ... */
	
	while( num_chr < LINE_LEN ) {
		/* if lf/cr reached before filling buffer, return */
			if( (chr == CR) || (chr == LF) )
				break;
		
			/* if single-quote, treat rest of line as comment (4nec2 compat) */
			if( chr == '\'' ) {
				while( (chr != CR) && (chr != LF) )
					if( (chr = fgetc(pfile)) == EOF )
						return( EOF );
				break;
			}
		
			/* enter new char to buffer */
			buff[num_chr++] = static_cast<char>(chr);
	
		/* terminate buffer as a string on EOF */
		if( (chr = fgetc(pfile)) == EOF ) {
			buff[num_chr] = '\0';
			eof = EOF;
		}
	} /* end of while( num_chr < LINE_LEN ) */

	/* drain any characters past LINE_LEN so an over-length line
	 * cannot leak its tail into the next load_line read. Match the
	 * fill loop's EOF convention (set eof, fall through) rather than
	 * the single-quote drain's early return, so the buffer's mnemonic
	 * is still capitalized/terminated and the caller sees EOF. */
	while( (chr != CR) && (chr != LF) )
		if( (chr = fgetc(pfile)) == EOF ) {
			eof = EOF;
			break;
		}

	/* Capitalize first two characters (mnemonics) */
	    buff[0] = static_cast<char>(std::toupper(buff[0]));
	    buff[1] = static_cast<char>(std::toupper(buff[1]));
	    
	    /* terminate buffer as a string */
	buff[num_chr] = '\0';
	
	return( eof );
} /* end of load_line() */

/* C++ stream overload: identical logic, uses std::istream::get() */
int load_line( char *buff, std::istream& is )
{
	int num_chr = 0;
	int eof = 0;
	int chr;

	buff[0] = '\0';

	chr = is.get();
	if ( !is ) return EOF;

	while ( (chr == '#') || (chr == ' ') || (chr == CR) || (chr == LF) ) {
		while ( (chr != CR) && (chr != LF) ) {
			chr = is.get();
			if ( !is ) return EOF;
		}
		while ( (chr == CR) || (chr == LF) ) {
			chr = is.get();
			if ( !is ) return EOF;
		}
	}

	while ( num_chr < LINE_LEN ) {
		if ( (chr == CR) || (chr == LF) )
			break;

		if ( chr == '\'' ) {
			while ( (chr != CR) && (chr != LF) ) {
				chr = is.get();
				if ( !is ) return EOF;
			}
			break;
		}

		buff[num_chr++] = static_cast<char>(chr);

		chr = is.get();
		if ( !is ) {
			buff[num_chr] = '\0';
			eof = EOF;
		}
	}

	/* drain any characters past LINE_LEN so an over-length line
	 * cannot leak its tail into the next load_line read. Match the
	 * fill loop's EOF convention (set eof, fall through). */
	while ( (chr != CR) && (chr != LF) ) {
		chr = is.get();
		if ( !is ) {
			eof = EOF;
			break;
		}
	}

	buff[0] = static_cast<char>(std::toupper(buff[0]));
	buff[1] = static_cast<char>(std::toupper(buff[1]));
	buff[num_chr] = '\0';

	return eof;
}

